import asyncio
import logging
import os
import re

from dotenv import load_dotenv
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
from web3 import Web3

import src.database as database
from src.monitor import monitor_transfers

load_dotenv()
logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    level=logging.INFO,
)
log = logging.getLogger(__name__)

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
RPC_URL = os.getenv("CELO_RPC_URL", "https://rpc.celo-community.org")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.effective_message.reply_text(
        "Celo Telegram Monitor is ready.\n\n"
        "/status - Check RPC connection\n"
        "/wallet ADDRESS - Register a public Celo wallet\n"
        "/wallets - List your registered wallets\n"
        "/email EMAIL - Save an email reference you own/manage\n"
        "/emails - List your email references\n"
        "/claim STATUS [TX_HASH] - Log a claim/status manually\n"
        "/claims - Show recent claim records\n"
        "/help - Show help\n\n"
        "Security: never send passwords, seed phrases, or private keys here. "
        "This bot monitors public data; it does not bypass verification or submit faucet claims."
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await start(update, context)


async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        w3 = Web3(Web3.HTTPProvider(RPC_URL, request_kwargs={"timeout": 10}))
        if not w3.is_connected():
            await update.effective_message.reply_text("Celo RPC is not reachable right now.")
            return
        await update.effective_message.reply_text(
            f"Celo RPC connected.\nChain ID: {w3.eth.chain_id}\nLatest block: {w3.eth.block_number}"
        )
    except Exception:
        log.exception("RPC status failed")
        await update.effective_message.reply_text("RPC check failed. Check the endpoint or try again later.")


async def wallet(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.effective_message.reply_text("Usage: /wallet 0xYourPublicWalletAddress")
        return
    address = context.args[0]
    if not Web3.is_address(address):
        await update.effective_message.reply_text("That does not look like a valid EVM wallet address.")
        return
    address = Web3.to_checksum_address(address)
    user_id = update.effective_user.id
    database.add_wallet(user_id, address)
    database.audit(user_id, "wallet_added", address)
    try:
        w3 = Web3(Web3.HTTPProvider(RPC_URL, request_kwargs={"timeout": 10}))
        balance = Web3.from_wei(w3.eth.get_balance(address), "ether")
        await update.effective_message.reply_text(
            f"Wallet registered.\nAddress: {address}\nNative CELO balance: {balance} CELO\n\n"
            "Token notifications start after TOKEN_CONTRACT_ADDRESS is configured in .env."
        )
    except Exception:
        await update.effective_message.reply_text(
            f"Wallet registered: {address}\nCould not retrieve balance at the moment."
        )


async def wallets(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rows = database.list_wallets(update.effective_user.id)
    if not rows:
        await update.effective_message.reply_text("No wallets registered yet. Use /wallet ADDRESS.")
        return
    text = "\n".join(f"• {row['address']}" for row in rows)
    await update.effective_message.reply_text("Your wallets:\n" + text)


async def email_reference(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.effective_message.reply_text("Usage: /email you@example.com\nThis saves an email reference only; it does not log in to Gmail.")
        return
    email = context.args[0].strip().lower()
    if not EMAIL_RE.match(email):
        await update.effective_message.reply_text("Please enter a valid email address.")
        return
    database.add_email_reference(update.effective_user.id, email)
    database.audit(update.effective_user.id, "email_reference_added", email)
    await update.effective_message.reply_text(
        f"Saved email reference: {email}\nOAuth status: not connected.\n"
        "No password is stored. Gmail access requires a separate official OAuth setup."
    )


async def emails(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rows = database.list_email_references(update.effective_user.id)
    if not rows:
        await update.effective_message.reply_text("No email references saved. Use /email you@example.com.")
        return
    text = "\n".join(f"#{r['id']} {r['email']} — {r['oauth_status']}" for r in rows)
    await update.effective_message.reply_text("Email references:\n" + text)


async def claim(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.effective_message.reply_text(
            "Usage: /claim STATUS [TX_HASH]\n"
            "Example: /claim confirmed 0xabc...\n"
            "Allowed statuses: pending, confirmed, failed, rejected"
        )
        return
    status_value = context.args[0].lower()
    allowed = {"pending", "confirmed", "failed", "rejected"}
    if status_value not in allowed:
        await update.effective_message.reply_text("Status must be pending, confirmed, failed, or rejected.")
        return

    tx_hash = context.args[1] if len(context.args) > 1 else None
    if tx_hash and not re.fullmatch(r"0x[a-fA-F0-9]{64}", tx_hash):
        await update.effective_message.reply_text("Transaction hash must be a 0x-prefixed 32-byte hash.")
        return

    database.add_claim(
        telegram_user_id=update.effective_user.id,
        email_id=None,
        wallet=None,
        tx_hash=tx_hash,
        status=status_value,
        notes="Manually recorded by user; verify independently on-chain.",
    )
    database.audit(update.effective_user.id, "claim_logged", f"status={status_value}; tx={tx_hash or 'none'}")
    await update.effective_message.reply_text(
        "Claim record saved. This is a tracking record, not proof that the faucet claim succeeded."
    )


async def claims(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rows = database.list_claims(update.effective_user.id)
    if not rows:
        await update.effective_message.reply_text("No claim records yet. Use /claim pending [TX_HASH].")
        return
    lines = []
    for row in rows:
        lines.append(
            f"#{row['id']} | {row['status']} | {row['tx_hash'] or 'no tx hash'} | {row['created_at']}"
        )
    await update.effective_message.reply_text("Recent claim records:\n" + "\n".join(lines))


async def post_init(app: Application):
    app.create_task(monitor_transfers(app))


def main():
    if not TOKEN or TOKEN == "put_your_bot_token_here":
        raise RuntimeError("Set TELEGRAM_BOT_TOKEN in your .env file first.")
    database.init_db()
    app = Application.builder().token(TOKEN).post_init(post_init).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("status", status))
    app.add_handler(CommandHandler("wallet", wallet))
    app.add_handler(CommandHandler("wallets", wallets))
    app.add_handler(CommandHandler("email", email_reference))
    app.add_handler(CommandHandler("emails", emails))
    app.add_handler(CommandHandler("claim", claim))
    app.add_handler(CommandHandler("claims", claims))
    print("Celo Telegram Monitor is running. Press Ctrl+C to stop.")
    app.run_polling()


if __name__ == "__main__":
    main()
