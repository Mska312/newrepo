# Celo Telegram Monitor (Windows)

A beginner-friendly Telegram bot that:
- checks Celo RPC connectivity and latest block;
- registers public wallet addresses;
- reads native CELO balances;
- optionally monitors ERC-20 `Transfer` logs for a configured token contract;
- sends Telegram notifications for newly detected transfers;
- stores email references (not passwords) and manually entered claim tracking records in SQLite.

This is a monitoring and record-keeping project. It does not automatically submit faucet claims, automate identity verification, create Gmail accounts, or bypass eligibility rules.

## 1. Requirements
- Windows 10/11
- Python 3.11+ from https://www.python.org/downloads/windows/
- Telegram account
- A bot token created with the official @BotFather

## 2. Install
Open PowerShell in this folder:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If PowerShell blocks activation, use Command Prompt instead:

```bat
.venv\Scripts\activate.bat
```

## 3. Configure
Copy `.env.example` to `.env` and fill in `TELEGRAM_BOT_TOKEN`.
Keep `.env` private. Do not share it or upload it to GitHub.

The default RPC is a public community endpoint and may have rate limits. For production use, select a reliable RPC provider and follow its terms.

## 4. Run
```powershell
python bot.py
```

Open your bot in Telegram and try:
- `/start`
- `/status`
- `/wallet 0xYOUR_PUBLIC_CELO_ADDRESS`
- `/wallets`
- `/email you@example.com`
- `/emails`
- `/claim pending`
- `/claims`

## 5. Token transfer monitoring
Monitoring is disabled until you set `TOKEN_CONTRACT_ADDRESS` in `.env`.
Only use a contract address verified from an official source. Do not guess the USA₮ address.
After configuring it, restart the bot. The monitor starts tracking from the current block for newly registered wallets, then polls forward in bounded block ranges.

Public RPC endpoints may reject log queries, enforce range limits, or be unavailable. The bot logs errors; use a reliable endpoint if needed.

## 6. Gmail access
The `/email` command stores an email address as a reference only. It does not log in to Gmail.
Do not store Gmail passwords in SQLite. If actual mailbox access is needed for an account you control, add Google's official OAuth 2.0 flow and protect refresh tokens with OS or cloud secret storage. Only request the minimum Gmail scopes needed.

## 7. Database
SQLite database file: `bot_data.sqlite3` (created when the bot starts).
Tables include wallets, email_accounts, claims, audit_logs, seen_transfers, and settings.

Back up the database securely. It contains Telegram user IDs and wallet/email references.

## 8. Troubleshooting
- `python is not recognized`: reinstall Python and enable the PATH option, or try `py --version`.
- `ModuleNotFoundError`: activate `.venv` and run `pip install -r requirements.txt`.
- Telegram `Unauthorized`: check the token in `.env`; regenerate it in BotFather if exposed.
- RPC unavailable: check network connection or use a supported RPC provider.
- Token events not appearing: confirm the contract address, wallet address, chain, and RPC log-query support.
- Bot stops when terminal closes: expected for local development; a hosted deployment is a later step.

## Security
- Never send a bot token, Gmail password, private key, seed phrase, or recovery code to anyone.
- This bot uses public blockchain reads only; it does not need wallet signing keys.
- A saved claim record is user-entered and not independently verified as a faucet claim.
