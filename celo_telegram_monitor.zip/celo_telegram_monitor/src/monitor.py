import asyncio
import logging
import os

from web3 import Web3
from web3.exceptions import Web3Exception

import database

log = logging.getLogger(__name__)

TRANSFER_TOPIC = Web3.keccak(text="Transfer(address,address,uint256)").hex()


def topic_address(address: str) -> str:
    return "0x" + address.lower().replace("0x", "").rjust(64, "0")


def token_contract():
    raw = os.getenv("TOKEN_CONTRACT_ADDRESS", "").strip()
    if not raw:
        return None
    if not Web3.is_address(raw):
        raise ValueError("TOKEN_CONTRACT_ADDRESS is not a valid address")
    return Web3.to_checksum_address(raw)


async def monitor_transfers(app):
    """Poll token Transfer logs for registered wallets; only runs when a token is configured."""
    rpc_url = os.getenv("CELO_RPC_URL", "https://rpc.celo-community.org")
    interval = max(15, int(os.getenv("POLL_SECONDS", "20")))

    while True:
        try:
            contract = token_contract()
            if not contract:
                await asyncio.sleep(interval)
                continue

            w3 = Web3(Web3.HTTPProvider(rpc_url, request_kwargs={"timeout": 12}))
            if not w3.is_connected():
                log.warning("Celo RPC not connected")
                await asyncio.sleep(interval)
                continue

            latest = w3.eth.block_number
            wallets = database.get_all_wallets()
            # Start at the current block on first run; avoid scanning the entire chain.
            for row in wallets:
                user_id = row["telegram_user_id"]
                address = row["address"]
                last = int(row["last_checked_block"] or 0)
                if last == 0:
                    database.update_wallet_block(user_id, address, latest)
                    continue

                start = last + 1
                if start > latest:
                    continue

                # Bound the range to avoid oversized public RPC requests.
                end = min(latest, start + 199)
                padded = topic_address(address)
                filters = [
                    {
                        "fromBlock": start,
                        "toBlock": end,
                        "address": contract,
                        "topics": [TRANSFER_TOPIC, None, padded],
                    },
                    {
                        "fromBlock": start,
                        "toBlock": end,
                        "address": contract,
                        "topics": [TRANSFER_TOPIC, padded],
                    },
                ]

                for filt in filters:
                    try:
                        logs = w3.eth.get_logs(filt)
                    except Web3Exception as exc:
                        log.warning("Could not retrieve logs: %s", exc)
                        continue

                    for entry in logs:
                        tx_hash = entry["transactionHash"].hex()
                        log_index = int(entry["logIndex"])
                        if not database.mark_transfer_seen(tx_hash, log_index):
                            continue
                        direction = "received" if len(entry["topics"]) > 2 and entry["topics"][2].hex().lower().endswith(padded[-40:].lower()) else "sent"
                        try:
                            await app.bot.send_message(
                                chat_id=user_id,
                                text=(
                                    f"Token transfer detected ({direction}).\n"
                                    f"Wallet: {address}\n"
                                    f"Contract: {contract}\n"
                                    f"Transaction: {tx_hash}\n"
                                    f"Block: {entry['blockNumber']}"
                                ),
                            )
                        except Exception as exc:
                            log.warning("Telegram notification failed: %s", exc)

                database.update_wallet_block(user_id, address, end)

        except Exception:
            log.exception("Transfer monitor iteration failed")

        await asyncio.sleep(interval)
