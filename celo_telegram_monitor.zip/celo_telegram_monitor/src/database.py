import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone


DB_PATH = os.getenv("DATABASE_PATH", "bot_data.sqlite3")


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@contextmanager
def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with connect() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS wallets (
                telegram_user_id INTEGER NOT NULL,
                address TEXT NOT NULL,
                created_at TEXT NOT NULL,
                last_checked_block INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (telegram_user_id, address)
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS email_accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_user_id INTEGER NOT NULL,
                email TEXT NOT NULL,
                oauth_status TEXT NOT NULL DEFAULT 'not_connected',
                created_at TEXT NOT NULL,
                UNIQUE (telegram_user_id, email)
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS claims (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_user_id INTEGER NOT NULL,
                email_account_id INTEGER,
                wallet_address TEXT,
                tx_hash TEXT UNIQUE,
                status TEXT NOT NULL,
                notes TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY (email_account_id) REFERENCES email_accounts(id)
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS audit_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_user_id INTEGER,
                action TEXT NOT NULL,
                details TEXT,
                created_at TEXT NOT NULL
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS seen_transfers (
                tx_hash TEXT NOT NULL,
                log_index INTEGER NOT NULL,
                created_at TEXT NOT NULL,
                PRIMARY KEY (tx_hash, log_index)
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
        """)


def audit(user_id, action, details=""):
    with connect() as db:
        db.execute(
            "INSERT INTO audit_logs (telegram_user_id, action, details, created_at) VALUES (?, ?, ?, ?)",
            (user_id, action, details[:1000], now_utc()),
        )


def add_wallet(user_id: int, address: str):
    with connect() as db:
        db.execute(
            "INSERT OR IGNORE INTO wallets (telegram_user_id, address, created_at) VALUES (?, ?, ?)",
            (user_id, address, now_utc()),
        )


def list_wallets(user_id: int):
    with connect() as db:
        return db.execute(
            "SELECT address, created_at FROM wallets WHERE telegram_user_id=? ORDER BY created_at DESC",
            (user_id,),
        ).fetchall()


def get_all_wallets():
    with connect() as db:
        return db.execute(
            "SELECT telegram_user_id, address, last_checked_block FROM wallets"
        ).fetchall()


def update_wallet_block(user_id: int, address: str, block_num: int):
    with connect() as db:
        db.execute(
            "UPDATE wallets SET last_checked_block=? WHERE telegram_user_id=? AND address=?",
            (block_num, user_id, address),
        )


def add_email_reference(user_id: int, email: str):
    with connect() as db:
        db.execute(
            "INSERT OR IGNORE INTO email_accounts (telegram_user_id, email, oauth_status, created_at) VALUES (?, ?, 'not_connected', ?)",
            (user_id, email.lower(), now_utc()),
        )


def list_email_references(user_id: int):
    with connect() as db:
        return db.execute(
            "SELECT id, email, oauth_status, created_at FROM email_accounts WHERE telegram_user_id=? ORDER BY id DESC",
            (user_id,),
        ).fetchall()


def add_claim(user_id: int, email_id, wallet, tx_hash, status, notes=""):
    now = now_utc()
    with connect() as db:
        db.execute(
            """INSERT INTO claims
            (telegram_user_id, email_account_id, wallet_address, tx_hash, status, notes, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (user_id, email_id, wallet, tx_hash, status, notes[:1000], now, now),
        )


def update_claim_status(user_id: int, claim_id: int, status: str, notes=""):
    with connect() as db:
        db.execute(
            """UPDATE claims SET status=?, notes=?, updated_at=?
               WHERE id=? AND telegram_user_id=?""",
            (status, notes[:1000], now_utc(), claim_id, user_id),
        )


def list_claims(user_id: int, limit=10):
    with connect() as db:
        return db.execute(
            """SELECT c.id, c.wallet_address, c.tx_hash, c.status, c.notes,
                      c.created_at, e.email
               FROM claims c LEFT JOIN email_accounts e ON e.id=c.email_account_id
               WHERE c.telegram_user_id=?
               ORDER BY c.id DESC LIMIT ?""",
            (user_id, limit),
        ).fetchall()


def mark_transfer_seen(tx_hash: str, log_index: int) -> bool:
    with connect() as db:
        cur = db.execute(
            "INSERT OR IGNORE INTO seen_transfers (tx_hash, log_index, created_at) VALUES (?, ?, ?)",
            (tx_hash, log_index, now_utc()),
        )
        return cur.rowcount == 1


def get_setting(key: str, default=None):
    with connect() as db:
        row = db.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default


def set_setting(key: str, value: str):
    with connect() as db:
        db.execute(
            "INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, str(value)),
        )
